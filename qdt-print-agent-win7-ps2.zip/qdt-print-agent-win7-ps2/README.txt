QudingTong Windows 7 / PowerShell 2.0 Print Agent v1.3.5 AUTO HTTP

This Win7 package uses HTTP compatibility path to avoid old TLS failures.
The admin download package writes this customer URL and token automatically.
PowerShell 2.0 syntax and default dot-matrix continuous paper are supported.

Daily use:
  Start.bat            Auto-check config and keep printing monitor running.
Optional:
  Test.bat             Print test page and check server/token.
  Config.bat           Auto-write/refresh default config, no questions.
  ChoosePrinter.bat    Only if you need a non-default printer; this one asks questions.

Compatibility endpoint: filled by admin package
Paper: 240mm x 95.24mm continuous form
Paper orientation: portrait page with wide custom paper; content is printed horizontally.
paper_landscape: false by default. Set true only if the printer driver specifically requires Landscape.
Default printer: Windows default printer

Only Start.bat needs to stay open. Each customer must download the package from their own admin backend.
