# QudingTong Windows 7 / PowerShell 2.0 Print Agent v1.3.2
param([switch]$Configure,[switch]$TestPrinter,[switch]$AutoConfigure)
$ErrorActionPreference='Stop'
$Dir=Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigPath=Join-Path $Dir 'config.json'
$DefaultUrl='http://your-domain.example/qdt-print'
$DefaultToken=''
$Pending='/api/admin/print/jobs/pending'
$Health='/api/health'
$Seen=@{}

try { Add-Type -AssemblyName System.Web.Extensions -ErrorAction Stop } catch { Write-Host 'Need Microsoft .NET Framework 3.5 / System.Web.Extensions on Windows 7.'; exit 1 }
$script:JS=New-Object System.Web.Script.Serialization.JavaScriptSerializer
try { $script:JS.MaxJsonLength=16777216 } catch {}
try { [System.Net.ServicePointManager]::SecurityProtocol=[System.Net.SecurityProtocolType]::Tls12 } catch { try { [System.Net.ServicePointManager]::SecurityProtocol=[System.Net.SecurityProtocolType]3072 } catch {} }

function IsBlank($s){ if($s -eq $null){return $true}; return (([string]$s).Trim().Length -eq 0) }
function JsonEscape($s){
  if($s -eq $null){return ''}
  $x=([string]$s).Replace('\','\\').Replace('"','\"')
  $x=$x.Replace([string][char]13,'\r').Replace([string][char]10,'\n').Replace([string][char]9,'\t')
  return $x
}
function GetProp($o,$name){
  if($o -eq $null){return $null}
  try { if($o -is [System.Collections.IDictionary]){ if($o.Contains($name)){return $o[$name]} } } catch {}
  try { if($o.ContainsKey($name)){return $o[$name]} } catch {}
  try { if($o.PSObject -and $o.PSObject.Properties[$name]){return $o.PSObject.Properties[$name].Value} } catch {}
  return $null
}
function Cn($s){ if($s -eq $null){return ''}; return [string]$s }

function QBoolValue($v){return ($v -eq $true -or $v -eq 1 -or $v -eq '1' -or $v -eq 'true' -or $v -eq 'True')}
function QBoolJson($v){if(QBoolValue $v){return 'true'};return 'false'}
function SaveConfig($c){
  $json='{' +
    '"url":"'+(JsonEscape $c.url)+'",' +
    '"token":"'+(JsonEscape $c.token)+'",' +
    '"printer":"'+(JsonEscape $c.printer)+'",' +
    '"version":"1.3.2-win7-ps2",' +
    '"paper_width_mm":'+([string]$c.paper_width_mm)+',' +
    '"paper_height_mm":'+([string]$c.paper_height_mm)+',' +
    '"mode":"'+(JsonEscape $c.mode)+'",' +
    '"poll_ms":'+([string]$c.poll_ms)+',' +
    '"paper_landscape":'+(QBoolJson $c.paper_landscape)+
  '}'
  $enc=New-Object System.Text.UTF8Encoding -ArgumentList @($false)
  [IO.File]::WriteAllText($ConfigPath,$json,$enc)
}
function LoadConfig {
  if(-not(Test-Path -LiteralPath $ConfigPath)){return @{url=$DefaultUrl;token=$DefaultToken;printer='';paper_width_mm=240;paper_height_mm=95.24;mode='overlay';poll_ms=3000;paper_landscape=$false}}
  try {
    $text=[IO.File]::ReadAllText($ConfigPath,[Text.Encoding]::UTF8)
    $j=$script:JS.DeserializeObject($text)
    $u=GetProp $j 'url'; if(IsBlank $u){$u=$DefaultUrl}
    $t=GetProp $j 'token'; if(IsBlank $t){$t=''}
    $p=GetProp $j 'printer'; if(IsBlank $p){$p=''}
    $w=GetProp $j 'paper_width_mm'; if(IsBlank $w){$w=240}; try{$w=[double]$w}catch{$w=240}; if($w -le 0){$w=240}
    $h=GetProp $j 'paper_height_mm'; if(IsBlank $h){$h=95.24}; try{$h=[double]$h}catch{$h=95.24}; if($h -le 0){$h=95.24}
    $m=GetProp $j 'mode'; if(IsBlank $m){$m='overlay'}
    $poll=GetProp $j 'poll_ms'; if(IsBlank $poll){$poll=3000}; try{$poll=[int]$poll}catch{$poll=3000}; if($poll -lt 1000){$poll=3000}
    $land=GetProp $j 'paper_landscape'; if(IsBlank $land){$land=$false}
    return @{url=[string]$u;token=[string]$t;printer=[string]$p;paper_width_mm=$w;paper_height_mm=$h;mode=[string]$m;poll_ms=$poll;paper_landscape=(QBoolValue $land)}
  } catch { return @{url=$DefaultUrl;token=$DefaultToken;printer='';paper_width_mm=240;paper_height_mm=95.24;mode='overlay';poll_ms=3000;paper_landscape=$false} }
}
function Printers {
  $arr=@()
  try { $arr=@(Get-WmiObject Win32_Printer -ErrorAction Stop | ForEach-Object { $_.Name }) } catch {}
  return $arr
}
function ShowPrinters {
  $a=@(Printers)
  Write-Host 'Printers:'
  if($a.Count -eq 0){Write-Host '  none detected; blank=default';return}
  for($i=0;$i -lt $a.Count;$i++){Write-Host ('  '+($i+1)+'. '+$a[$i])}
  Write-Host '  0. Default'
}
function Invoke-QdtApi($path,$method,$body){
  $uri=$script:Config.url.TrimEnd([char]'/')+$path
  $req=[System.Net.WebRequest]::Create($uri)
  $req.Method=$method
  $req.ContentType='application/json'
  $req.Timeout=20000
  if(-not (IsBlank $script:Config.token)){ $req.Headers.Add('x-qdt-agent-token',$script:Config.token) }
  if($body -ne $null){
    $bytes=[Text.Encoding]::UTF8.GetBytes([string]$body)
    $req.ContentLength=$bytes.Length
    $st=$req.GetRequestStream();$st.Write($bytes,0,$bytes.Length);$st.Close()
  }
  $resp=$null
  try { $resp=$req.GetResponse() } catch {
    $msg=$_.Exception.Message
    try {
      $er=$_.Exception.Response
      if($er -ne $null){
        $es=$er.GetResponseStream()
        if($es -ne $null){$sr=New-Object IO.StreamReader($es,[Text.Encoding]::UTF8);$et=$sr.ReadToEnd();$sr.Close();if(-not (IsBlank $et)){$msg=$msg+' '+$et}}
      }
    } catch {}
    throw $msg
  }
  $stream=$resp.GetResponseStream()
  $reader=New-Object IO.StreamReader($stream,[Text.Encoding]::UTF8)
  $text=$reader.ReadToEnd()
  $reader.Close();$stream.Close();$resp.Close()
  if(IsBlank $text){return @{}}
  return $script:JS.DeserializeObject($text)
}
function SetPaper($pd,$c){
  try {
    $w=[int][Math]::Round([double]$c.paper_width_mm/25.4*100)
    $h=[int][Math]::Round([double]$c.paper_height_mm/25.4*100)
    $sz=New-Object System.Drawing.Printing.PaperSize -ArgumentList @('QDT241',$w,$h)
    $pd.DefaultPageSettings.PaperSize=$sz
    $land=$false;if($c -ne $null -and (GetProp $c 'paper_landscape') -ne $null){$land=QBoolValue (GetProp $c 'paper_landscape')};$pd.DefaultPageSettings.Landscape=$land
    $mg=New-Object System.Drawing.Printing.Margins -ArgumentList @(0,0,0,0)
    $pd.DefaultPageSettings.Margins=$mg
  } catch {}
}
function QProp($o,$n){
  if($o -eq $null){return $null}
  try { if($o -is [System.Collections.IDictionary]){ if($o.Contains($n)){return $o[$n]} } } catch {}
  try { if($o.ContainsKey($n)){return $o[$n]} } catch {}
  try { if($o.PSObject -and $o.PSObject.Properties[$n]){return $o.PSObject.Properties[$n].Value} } catch {}
  return $null
}
function QMM($v){try{return [double]$v/25.4*100}catch{return 0}}
function QD($g,$f,$t,$x,$y){$g.DrawString([string](Cn $t),$f,[Drawing.Brushes]::Black,[single]$x,[single]$y)}
function QBool($v){return ($v -eq $true -or $v -eq 1 -or $v -eq '1' -or $v -eq 'true')}
function DrawConfiguredJob($g,$d,$font,$small,$bold,$pen){
  $cfg=QProp $d 'print_config'; if($cfg -eq $null){return $false}
  $positions=QProp $cfg 'positions'; $hidden=QProp $cfg 'hidden'; $custom=QProp $cfg 'customBlocks'
  $footer=QProp $cfg 'footer'; $fields=QProp $cfg 'fields'; $paper=QProp $cfg 'paper'; $rows=QProp $cfg 'rows'; $colsCfg=QProp $cfg 'columns'
  $L=QProp $d 'labels'; $C=QProp $cfg 'company'; $footerData=QProp $cfg 'footer'; $footer=$footerData; $items=QProp $d 'items'; if($items -eq $null){$items=@()}else{$items=@($items)}
  $pageWmm=240;$mr=6;$ml=6;$mt=5;$tg=2;$hg=2;$fg=2;$toff=0
  if($paper -ne $null){$v=QProp $paper 'width_mm';if($v){$pageWmm=[double]$v};$v=QProp $paper 'margin_right_mm';if($v){$mr=[double]$v};$v=QProp $paper 'margin_left_mm';if($v){$ml=[double]$v};$v=QProp $paper 'margin_top_mm';if($v){$mt=[double]$v};$v=QProp $paper 'title_gap_mm';if($v){$tg=[double]$v};$v=QProp $paper 'head_gap_mm';if($v){$hg=[double]$v};$v=QProp $paper 'foot_gap_mm';if($v){$fg=[double]$v};$v=QProp $paper 'title_offset_x_mm';if($v){$toff=[double]$v}}
  $tp=QProp $positions 'table'; if($tp -eq $null){$tp=@{x=6;y=28}}
  $tx=QMM($ml+[double](QProp $tp 'x'));$ty=QMM($mt+$hg+[double](QProp $tp 'y'))
  $twmm=$pageWmm-[double](QProp $tp 'x')-$ml-$mr;if($twmm -lt 40){$twmm=40};$tw=QMM($twmm)
  $buyer=Cn(QProp $d 'buyer');$pay=Cn(QProp $d 'pay_method')
  $book=[string]::Join('',@([char]0x8BB0,[char]0x8D26));$credit=[string]::Join('',@([char]0x8D26,[char]0x671F));if($pay -eq $book){$pay=$credit}
  $bl=Cn(QProp $fields 'buyer');if([string]::IsNullOrEmpty($bl)){$bl=Cn(QProp $L 'buyer')}
  $sd=Cn(QProp $fields 'saleDate');if([string]::IsNullOrEmpty($sd)){$sd=Cn(QProp $L 'saleDate')}
  $bn=Cn(QProp $fields 'billNo');if([string]::IsNullOrEmpty($bn)){$bn=Cn(QProp $L 'billNo')}
  $ca=Cn(QProp $fields 'customerAddress');if([string]::IsNullOrEmpty($ca)){$ca=Cn(QProp $L 'customerAddress')}
  $cp=Cn(QProp $fields 'customerPhone');if([string]::IsNullOrEmpty($cp)){$cp=Cn(QProp $L 'customerPhone')}
  $op=Cn(QProp $fields 'operator');if([string]::IsNullOrEmpty($op)){$op=Cn(QProp $L 'operator')}
  $cl=Cn(QProp $footer 'customer_label');if([string]::IsNullOrEmpty($cl)){$cl=Cn(QProp $L 'customer')}
  $bk=Cn(QProp $footer 'bank_label');if([string]::IsNullOrEmpty($bk)){$bk=Cn(QProp $L 'bank')}
  $pd=Cn(QProp $footer 'paid_label');if([string]::IsNullOrEmpty($pd)){$pd=Cn(QProp $L 'paid')}
  $sg=Cn(QProp $footer 'signature_label');if([string]::IsNullOrEmpty($sg)){$sg=Cn(QProp $L 'signature')}
  $pm=Cn(QProp $footer 'pay_method_label');if([string]::IsNullOrEmpty($pm)){$pm=Cn(QProp $L 'pay_method')}
  $companyLine=[string]::Join(' ',@((Cn(QProp $C 'name')),(Cn(QProp $C 'address')),(Cn(QProp $C 'phone')),(Cn(QProp $C 'footer')))).Trim()
  $texts=@{}
  $texts['title']=Cn(QProp $L 'title');if((Cn(QProp $d 'doc_type')) -eq 'return'){$texts['title']=Cn(QProp $d 'return_title')}
  $texts['buyer']=$bl+': '+$buyer
  $texts['dateNo']=$sd+': '+(Cn(QProp $d 'sale_date'))+'   '+$bn+': '+(Cn(QProp $d 'bill_no'))
  $texts['address']=$ca+': '+(Cn(QProp $d 'customer_address'))
  $texts['phone']=$cp+': '+(Cn(QProp $d 'customer_phone'))
  $texts['operator']=$op+': '+(Cn(QProp $d 'operator'))
  $texts['bottomCustomer']=$cl+': '+$buyer
  $texts['bottomCompany']=$companyLine
  $texts['bottomBank']=$bk+': '+(Cn(QProp $footer 'bank_account'))
  $texts['bottomPaid']=$pd+': '+(Cn(QProp $d 'paid_amount'))
  $texts['bottomPay']=$pm+': '+$pay
  $texts['bottomSignature']=$sg+': '+(Cn(QProp $footer 'signature_value'))
  $texts['bottomNote']=Cn(QProp $footer 'note')
  $keys=@('title','buyer','dateNo','address','phone','operator','bottomCustomer','bottomCompany','bottomBank','bottomPaid','bottomPay','bottomSignature','bottomNote')
  foreach($k in $keys){
    if(QBool(QProp $hidden $k)){continue}
    if($k -eq 'bottomCustomer' -and (QProp $footer 'show_customer') -eq $false){continue}
    if($k -eq 'bottomCompany' -and (QProp $footer 'show_company') -eq $false){continue}
    if($k -eq 'bottomBank' -and (QProp $footer 'show_bank') -eq $false){continue}
    if($k -eq 'bottomPaid' -and (QProp $footer 'show_paid') -eq $false){continue}
    if($k -eq 'bottomPay' -and (QProp $footer 'show_pay_method') -eq $false){continue}
    if($k -eq 'bottomSignature' -and (QProp $footer 'show_signature') -eq $false){continue}
    $p=QProp $positions $k;if($p -eq $null){continue}
    $x=QMM($ml+[double](QProp $p 'x'));$titleOffset=QMM($toff);$dy=$mt+$tg;if($k -eq 'title'){$dy=$mt;$x=$x+$titleOffset}elseif($k.StartsWith('bottom')){$dy=$mt+$fg}
    $y=QMM($dy+[double](QProp $p 'y'));$txt=[string]($texts[$k]);if([string]::IsNullOrEmpty($txt)){continue}
    if($k -eq 'title'){$sf=New-Object System.Drawing.StringFormat;$ta=Cn(QProp $paper 'title_align');if($ta -eq 'left'){$sf.Alignment=[System.Drawing.StringAlignment]::Near}elseif($ta -eq 'right'){$sf.Alignment=[System.Drawing.StringAlignment]::Far}else{$sf.Alignment=[System.Drawing.StringAlignment]::Center};$rect=New-Object System.Drawing.RectangleF([single]$x,[single]$y,[single]$tw,[single]36);$g.DrawString($txt,$bold,[Drawing.Brushes]::Black,$rect,$sf)}else{QD $g $small $txt $x $y}
  }
  if($custom -ne $null){foreach($b in @($custom)){$k=Cn(QProp $b 'key');if(QBool(QProp $hidden $k)){continue};$p=QProp $positions $k;if($p -eq $null){continue};$x=QMM($ml+[double](QProp $p 'x'));$y=QMM($mt+$tg+[double](QProp $p 'y'));QD $g $small (Cn(QProp $b 'text')) $x $y}}
  $vcols=@();if($colsCfg -ne $null){foreach($c in @($colsCfg)){if((QProp $c 'show') -ne $false){$vcols+=$c}}}
  if($vcols.Count -eq 0){return $true}
  $widths=@();$sum=0;foreach($c in $vcols){$pct=0;try{$pct=[double](([string](QProp $c 'width')).Replace('%',''))}catch{$pct=0};if($pct -le 0){$pct=10};$widths+=$pct;$sum+=$pct};if($sum -le 0){$sum=100}
  $colX=@();$cur=$tx;foreach($w in $widths){$colX+=$cur;$cur+=$tw*$w/$sum};$colX+=$tx+$tw
  $hh=QMM([double](QProp $rows 'header_height'));if($hh -le 0){$hh=QMM(8)}
  $rh=QMM([double](QProp $rows 'item_height'));if($rh -le 0){$rh=QMM(8)}
  $fh=QMM([double](QProp $rows 'footer_height'));if($fh -le 0){$fh=QMM(9)}
  $n=0;try{$n=[int](QProp $rows 'item_rows')}catch{$n=0};if($n -lt 1){$n=8};if($n -gt 30){$n=30};if($items.Count -gt $n){$n=$items.Count}
  $y=$ty;for($k=0;$k -lt $vcols.Count;$k++){$g.DrawRectangle($pen,[single]$colX[$k],[single]$y,[single]($colX[$k+1]-$colX[$k]),[single]$hh);QD $g $small (Cn(QProp $vcols[$k] 'label')) ($colX[$k]+2) ($y+2)};$y+=$hh
  for($i=0;$i -lt $n;$i++){$it=$null;if($i -lt $items.Count){$it=$items[$i]};for($k=0;$k -lt $vcols.Count;$k++){$key=Cn(QProp $vcols[$k] 'key');$val=QProp $it $key;if($key -eq 'index' -and [string]::IsNullOrEmpty([string](Cn $val))){$val=$i+1};if($key -eq 'pay_method'){$val=$pay};$g.DrawRectangle($pen,[single]$colX[$k],[single]$y,[single]($colX[$k+1]-$colX[$k]),[single]$rh);QD $g $small (Cn $val) ($colX[$k]+2) ($y+2)};$y+=$rh}
  $tot=@{index=Cn(QProp $L 'total');name=(Cn(QProp $d 'sale_time'))+' '+(Cn(QProp $d 'sale_date'));qty=Cn(QProp $d 'total_qty');amount=Cn(QProp $d 'total_amount');pay_method=$pay}
  for($k=0;$k -lt $vcols.Count;$k++){$key=Cn(QProp $vcols[$k] 'key');$val='';if($tot.ContainsKey($key)){$val=$tot[$key]};$g.DrawRectangle($pen,[single]$colX[$k],[single]$y,[single]($colX[$k+1]-$colX[$k]),[single]$fh);QD $g $small $val ($colX[$k]+2) ($y+2)}
  return $true
}

function PrintJobObject($c,$obj,$printerName){
  [void][Reflection.Assembly]::LoadWithPartialName('System.Drawing')
  $pd=New-Object System.Drawing.Printing.PrintDocument
  if(-not (IsBlank $printerName)){ $pd.PrinterSettings.PrinterName=$printerName; if(-not $pd.PrinterSettings.IsValid){throw 'Printer not available: '+$printerName} }
  $pjPaper=QProp $obj 'paper';if($pjPaper -ne $null){$w=QProp $pjPaper 'width_mm';$h=QProp $pjPaper 'height_mm';if($w){$c.paper_width_mm=[double]$w};if($h){$c.paper_height_mm=[double]$h}}
  SetPaper $pd $c
  $font=New-Object System.Drawing.Font -ArgumentList @('Microsoft YaHei',[single]9)
  $small=New-Object System.Drawing.Font -ArgumentList @('Microsoft YaHei',[single]8)
  $bold=New-Object System.Drawing.Font -ArgumentList @('Microsoft YaHei',[single]15,[System.Drawing.FontStyle]::Bold)
  $pen=[System.Drawing.Pens]::Black
  $script:payload=$obj
  $handler=[System.Drawing.Printing.PrintPageEventHandler]{
    param($sender,$e)
    $g=$e.Graphics
    $d=$script:payload
    if(DrawConfiguredJob $g $d $font $small $bold $pen){$e.HasMorePages=$false;return}
    $L=GetProp $d 'labels'; if($L -eq $null){$L=@{}}
    $C=GetProp $d 'company'; if($C -eq $null){$C=@{}}
    $items=GetProp $d 'items'; if($items -eq $null){$items=@()} else {$items=@($items)}
    $heads=GetProp $L 'columns'; if($heads -eq $null){$heads=@('No','Name','Unit','Qty','Price','Amount','Note')} else {$heads=@($heads)}
    if($heads.Count -lt 7){$heads=@('No','Name','Unit','Qty','Price','Amount','Note')}
    $W=945;$H=375;$left=20;$right=$W-20
    $title=Cn (GetProp $L 'title'); if(IsBlank $title){$title='QudingTong Delivery Note'}
    $ta=Cn (GetProp $d 'title_align');if(IsBlank $ta){$ta='center'}
    $toff=GetProp $d 'title_offset_x_mm';if(IsBlank $toff){$toff=0};try{$toff=[single]$toff/25.4*100}catch{$toff=0}
    $sf=New-Object System.Drawing.StringFormat
    if($ta -eq 'left'){$sf.Alignment=[System.Drawing.StringAlignment]::Near}elseif($ta -eq 'right'){$sf.Alignment=[System.Drawing.StringAlignment]::Far}else{$sf.Alignment=[System.Drawing.StringAlignment]::Center}
    $rect=New-Object System.Drawing.RectangleF -ArgumentList @([single]($left+$toff),[single]12,[single]($right-$left),[single]36)
    $g.DrawString($title,$bold,[Drawing.Brushes]::Black,$rect,$sf)
    $g.DrawString(((Cn (GetProp $L 'buyer'))+': '+(Cn (GetProp $d 'buyer'))),$font,[Drawing.Brushes]::Black,[single]25,[single]42)
    $g.DrawString(((Cn (GetProp $L 'saleDate'))+': '+(Cn (GetProp $d 'sale_date'))+'   '+(Cn (GetProp $L 'billNo'))+': '+(Cn (GetProp $d 'bill_no'))),$font,[Drawing.Brushes]::Black,[single]470,[single]42)
    $g.DrawString(((Cn (GetProp $L 'customerAddress'))+': '+(Cn (GetProp $d 'customer_address'))),$font,[Drawing.Brushes]::Black,[single]25,[single]62)
    $g.DrawString(((Cn (GetProp $L 'customerPhone'))+': '+(Cn (GetProp $d 'customer_phone'))),$font,[Drawing.Brushes]::Black,[single]470,[single]62)
    $g.DrawString(((Cn (GetProp $L 'operator'))+': '+(Cn (GetProp $d 'operator'))),$font,[Drawing.Brushes]::Black,[single]470,[single]82)
    $ty=92;$rh=25;$cols=@(0,50,455,510,565,635,720,835,$right)
    for($k=0;$k -lt $cols.Count-1;$k++){$g.DrawRectangle($pen,[single]$cols[$k],[single]$ty,[single]($cols[$k+1]-$cols[$k]),[single]$rh)}
    for($k=0;$k -lt 7;$k++){$g.DrawString((Cn $heads[$k]),$small,[Drawing.Brushes]::Black,[single]($cols[$k]+4),[single]($ty+5))}
    $y=$ty+$rh
    for($i=0;$i -lt 9;$i++){
      $x=$null;if($i -lt $items.Count){$x=$items[$i]}
      for($k=0;$k -lt $cols.Count-1;$k++){$g.DrawRectangle($pen,[single]$cols[$k],[single]$y,[single]($cols[$k+1]-$cols[$k]),[single]$rh)}
      $g.DrawString((Cn (GetProp $x 'index')),$small,[Drawing.Brushes]::Black,[single]($cols[0]+4),[single]($y+5))
      $g.DrawString((Cn (GetProp $x 'name')),$small,[Drawing.Brushes]::Black,[single]($cols[1]+4),[single]($y+5))
      $g.DrawString((Cn (GetProp $x 'unit')),$small,[Drawing.Brushes]::Black,[single]($cols[2]+4),[single]($y+5))
      $g.DrawString((Cn (GetProp $x 'qty')),$small,[Drawing.Brushes]::Black,[single]($cols[3]+4),[single]($y+5))
      $g.DrawString((Cn (GetProp $x 'unit_price')),$small,[Drawing.Brushes]::Black,[single]($cols[4]+4),[single]($y+5))
      $g.DrawString((Cn (GetProp $x 'amount')),$small,[Drawing.Brushes]::Black,[single]($cols[5]+4),[single]($y+5))
      $g.DrawString((Cn (GetProp $x 'note')),$small,[Drawing.Brushes]::Black,[single]($cols[6]+4),[single]($y+5))
      $y+=$rh
    }
    for($k=0;$k -lt $cols.Count-1;$k++){$g.DrawRectangle($pen,[single]$cols[$k],[single]$y,[single]($cols[$k+1]-$cols[$k]),[single]$rh)}
    $g.DrawString((Cn (GetProp $L 'total')),$small,[Drawing.Brushes]::Black,[single]($cols[0]+4),[single]($y+5))
    $g.DrawString((((Cn (GetProp $d 'sale_time'))+' '+(Cn (GetProp $d 'sale_date')))),$small,[Drawing.Brushes]::Black,[single]($cols[1]+4),[single]($y+5))
    $g.DrawString((Cn (GetProp $d 'total_qty')),$small,[Drawing.Brushes]::Black,[single]($cols[3]+4),[single]($y+5))
    $g.DrawString((Cn (GetProp $d 'total_amount')),$small,[Drawing.Brushes]::Black,[single]($cols[5]+4),[single]($y+5))
    $fy=$y+$rh+6
    $g.DrawString(((Cn (GetProp $L 'bank'))+': '+(Cn (GetProp $d 'bank_account'))),$small,[Drawing.Brushes]::Black,[single]25,[single]$fy)
    $g.DrawString(((Cn (GetProp $L 'paid'))+': '+(Cn (GetProp $d 'paid_amount'))),$small,[Drawing.Brushes]::Black,[single]360,[single]$fy)
    $g.DrawString(((Cn (GetProp $L 'signature'))+':'),$small,[Drawing.Brushes]::Black,[single]650,[single]$fy)
    $g.DrawString((((Cn (GetProp $C 'address'))+'  '+(Cn (GetProp $C 'phone'))+'  '+(Cn (GetProp $C 'footer')))),$small,[Drawing.Brushes]::Black,[single]25,[single]($fy+20))
    $e.HasMorePages=$false
  }
  $pd.add_PrintPage($handler)
  $pd.Print()
}
function PrintText($c,$text,$printerName){
  [void][Reflection.Assembly]::LoadWithPartialName('System.Drawing')
  $pd=New-Object System.Drawing.Printing.PrintDocument
  if(-not (IsBlank $printerName)){$pd.PrinterSettings.PrinterName=$printerName}
  SetPaper $pd $c
  $font=New-Object System.Drawing.Font -ArgumentList @('Microsoft YaHei',[single]10)
  $script:lines=([string]$text) -split '\r?\n'
  $handler=[System.Drawing.Printing.PrintPageEventHandler]{
    param($sender,$e)
    $g=$e.Graphics;$y=20.0
    foreach($line in $script:lines){$g.DrawString([string]$line,$font,[Drawing.Brushes]::Black,[single]20,[single]$y);$y+=18}
    $e.HasMorePages=$false
  }
  $pd.add_PrintPage($handler)
  $pd.Print()
}

if($AutoConfigure){
  $c=LoadConfig
  if(IsBlank $c.token){$c.token=$DefaultToken}
  if(IsBlank $c.url){$c.url=$DefaultUrl}
  SaveConfig $c
  $label='Windows default';if(-not (IsBlank $c.printer)){$label=$c.printer}
  Write-Host 'Auto configuration ready. No input required.'
  Write-Host ('URL='+$c.url+' Printer='+$label+' Paper='+$c.paper_width_mm+'x'+$c.paper_height_mm+'mm')
  exit 0
}
if($Configure){
  $c=LoadConfig
  $u=Read-Host ('URL (Enter='+$DefaultUrl+')');if(-not (IsBlank $u)){$c.url=([string]$u).Trim().TrimEnd([char]'/')}
  $t=Read-Host 'Agent token (Enter=keep preset)';if(-not (IsBlank $t)){$c.token=([string]$t).Trim()}
  ShowPrinters
  $p=Read-Host 'Printer number/name (Enter=default,*=list)';if($p -eq '*'){ShowPrinters;$p=Read-Host 'Printer number/name'}
  if(IsBlank $p){$c.printer=''} elseif(($p -match '^[0-9]+$') -and ([int]$p -gt 0)){$a=@(Printers);$i=[int]$p;if($i -le $a.Count){$c.printer=[string]$a[$i-1]}else{$c.printer=[string]$p}} else {$c.printer=[string]$p}
  SaveConfig $c
  Write-Host ('Saved URL='+$c.url+' Printer='+$c.printer)
  exit 0
}
$script:Config=LoadConfig
if(IsBlank $script:Config.token){throw 'Missing token'}
if($TestPrinter){
  $label='Windows default';if(-not (IsBlank $script:Config.printer)){$label=$script:Config.printer}
  Write-Host ('Testing printer: '+$label)
  $testFile=Join-Path $Dir 'test-print.txt'
  $testText=[IO.File]::ReadAllText($testFile,[Text.Encoding]::UTF8)
  PrintText $script:Config $testText $script:Config.printer
  $h=Invoke-QdtApi $Health 'GET' $null
  Write-Host ('Server '+(Cn (GetProp $h 'version'))+' / '+(Cn (GetProp $h 'security_level')))
  $j=Invoke-QdtApi $Pending 'GET' $null
  $rows=GetProp $j 'rows';if($rows -eq $null){$rows=@()}else{$rows=@($rows)}
  Write-Host ('Token OK. Pending='+$rows.Count)
  Write-Host 'Test finished';exit 0
}
Write-Host '=== QudingTong Print Agent v1.3.2 Win7/PS2 started ==='
$label='Windows default';if(-not (IsBlank $script:Config.printer)){$label=$script:Config.printer}
Write-Host ('URL='+$script:Config.url+' Printer='+$label+' Paper='+$script:Config.paper_width_mm+'x'+$script:Config.paper_height_mm+'mm Poll='+$script:Config.poll_ms+'ms')
while($true){
  try{
    $j=Invoke-QdtApi $Pending 'GET' $null
    $rows=GetProp $j 'rows';if($rows -eq $null){$rows=@()}else{$rows=@($rows)}
    foreach($job in $rows){
      $id=[string](GetProp $job 'id')
      if($Seen.ContainsKey($id)){continue}
      $Seen[$id]=$true
      $claimToken=[guid]::NewGuid().ToString('N')
      $claimBody='{"token":"'+$claimToken+'"}'
      $claim=Invoke-QdtApi ('/api/admin/print/jobs/'+$id+'/claim') 'POST' $claimBody
      $ok=GetProp $claim 'ok';$claimed=GetProp $claim 'claimed'
      if(-not $ok -or -not $claimed){continue}
      $serverToken=Cn (GetProp $claim 'token')
      try{
        $raw=Cn (GetProp $job 'payload')
        $obj=$null
        try{if(-not (IsBlank $raw)){$obj=$script:JS.DeserializeObject($raw)}}catch{}
        if($obj -ne $null -and (Cn (GetProp $obj 'type')) -eq 'delivery_note'){PrintJobObject $script:Config $obj $script:Config.printer}else{PrintText $script:Config $raw $script:Config.printer}
        $doneBody='{"status":"OK","error":"","token":"'+(JsonEscape $serverToken)+'"}'
        [void](Invoke-QdtApi ('/api/admin/print/jobs/'+$id+'/status') 'POST' $doneBody)
        Write-Host ('['+(Get-Date -Format 'HH:mm:ss')+'] Printed '+(Cn (GetProp $job 'order_no')))
      }catch{
        $err=[string]$_.Exception.Message
        Write-Host ('Print failed '+(Cn (GetProp $job 'order_no'))+': '+$err)
        $failBody='{"status":"FAIL","error":"'+(JsonEscape $err)+'","token":"'+(JsonEscape $serverToken)+'"}'
        try{[void](Invoke-QdtApi ('/api/admin/print/jobs/'+$id+'/status') 'POST' $failBody)}catch{}
      }
    }
  }catch{Write-Host ('['+(Get-Date -Format 'HH:mm:ss')+'] Poll failed: '+$_.Exception.Message)}
  Start-Sleep -Milliseconds $script:Config.poll_ms
}