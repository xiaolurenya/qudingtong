QudingTong Windows 10/11 / PowerShell 5.1+ Print Agent v1.3.5 AUTO CONFIG

The admin download package writes this customer URL and token automatically.
Default dot-matrix continuous paper is supported.

Daily use:
  Start.bat            Auto-check config and keep printing monitor running.
Optional:
  Test.bat             Print test page and check server/token.
  Config.bat           Auto-write/refresh default config, no questions.
  ChoosePrinter.bat    Only if you need a non-default printer; this one asks questions.

Server: filled by admin package
Paper: 240mm x 95.24mm continuous form
Paper orientation: portrait page with wide custom paper; content is printed horizontally.
paper_landscape: false by default. Set true only if the printer driver specifically requires Landscape.
Default printer: Windows default printer

Only Start.bat needs to stay open. Each customer must download the package from their own admin backend.
