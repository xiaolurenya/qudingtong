#Requires -Version 5.1
param([switch]$Configure,[switch]$TestPrinter,[switch]$AutoConfigure)
$ErrorActionPreference='Stop'
$Dir=Split-Path -Parent $MyInvocation.MyCommand.Path
$Config=Join-Path $Dir 'config.json'
$DefaultUrl='https://your-domain.example'
$DefaultToken=''
$Pending='/api/admin/print/jobs/pending'
$Health='/api/health'
$Done='OK'
$Failed='FAIL'
$Seen=@{}
function LoadConfig {
  if(-not(Test-Path -LiteralPath $Config)){return @{url=$DefaultUrl;token=$DefaultToken;printer='';paper_width_mm=240;paper_height_mm=95.24;mode='overlay';paper_landscape=$false}}
  try{$j=Get-Content -LiteralPath $Config -Raw -Encoding UTF8|ConvertFrom-Json;$w=240;if($j.paper_width_mm){$w=[double]$j.paper_width_mm};$h=95.24;if($j.paper_height_mm){$h=[double]$j.paper_height_mm};$m='overlay';if($j.mode){$m=[string]$j.mode};$land=$false;if($j.paper_landscape){$land=[bool]$j.paper_landscape};return @{url=[string]$j.url;token=[string]$j.token;printer=[string]$j.printer;paper_width_mm=$w;paper_height_mm=$h;mode=$m;paper_landscape=$land}}catch{return @{url=$DefaultUrl;token=$DefaultToken;printer='';paper_width_mm=240;paper_height_mm=95.24;mode='overlay';paper_landscape=$false}}
}
function SaveConfig($c){$o=[ordered]@{url=$c.url;token=$c.token;printer=$c.printer;version='1.3.2';paper_width_mm=$c.paper_width_mm;paper_height_mm=$c.paper_height_mm;mode=$c.mode;paper_landscape=$c.paper_landscape};[IO.File]::WriteAllText($Config,($o|ConvertTo-Json),[Text.UTF8Encoding]::new($false))}
function Printers{try{return @(Get-Printer|Select-Object -ExpandProperty Name)}catch{try{return @(Get-CimInstance Win32_Printer|Select-Object -ExpandProperty Name)}catch{return @()}}}
function ShowPrinters{$a=Printers;Write-Host 'Printers:';if(-not $a.Count){Write-Host '  none detected; blank=default';return};for($i=0;$i -lt $a.Count;$i++){Write-Host ('  '+($i+1)+'. '+$a[$i])};Write-Host '  0. Default'}
function Api($c,$path,$method,$body){$h=@{'Content-Type'='application/json; charset=utf-8';'x-qdt-agent-token'=$c.token};$a=@{Uri=($c.url.TrimEnd('/')+$path);Method=$method;Headers=$h;TimeoutSec=20;UseBasicParsing=$true};if($null -ne $body){$json=($body|ConvertTo-Json -Depth 8 -Compress);$bytes=[Text.Encoding]::UTF8.GetBytes([string]$json);$a.Body=$bytes;$h['Content-Length']=$bytes.Length};$r=Invoke-WebRequest @a;$s=[string]$r.Content;if([string]::IsNullOrWhiteSpace($s)){return @{}};return ($s|ConvertFrom-Json)}
function IsBlank($s){ if($s -eq $null){return $true}; return (([string]$s).Trim().Length -eq 0) }
function Cn($s){if($null -eq $s){return ''};return [string]$s}
function DrawText($g,$font,$text,$x,$y){$g.DrawString((Cn $text),$font,[Drawing.Brushes]::Black,[single]$x,[single]$y)}
function SetPaper($pd,$c){try{$w=[int][Math]::Round([double]$c.paper_width_mm/25.4*100);$h=[int][Math]::Round([double]$c.paper_height_mm/25.4*100);$sz=New-Object System.Drawing.Printing.PaperSize('QDT241',$w,$h);$pd.DefaultPageSettings.PaperSize=$sz;$land=$false;if($c.paper_landscape){$land=[bool]$c.paper_landscape};$pd.DefaultPageSettings.Landscape=$land;$pd.DefaultPageSettings.Margins=New-Object System.Drawing.Printing.Margins(0,0,0,0)}catch{}}
function QProp($o,$n){
  if($o -eq $null){return $null}
  try { if($o -is [System.Collections.IDictionary]){ if($o.Contains($n)){return $o[$n]} } } catch {}
  try { if($o.ContainsKey($n)){return $o[$n]} } catch {}
  try { if($o.PSObject -and $o.PSObject.Properties[$n]){return $o.PSObject.Properties[$n].Value} } catch {}
  return $null
}
function QMM($v){try{return [double]$v/25.4*100}catch{return 0}}
function QD($g,$f,$t,$x,$y){$g.DrawString([string](Cn $t),$f,[Drawing.Brushes]::Black,[single]$x,[single]$y)}
function QBool($v){return ($v -eq $true -or $v -eq 1 -or $v -eq '1' -or $v -eq 'true')}
function QCalNumSafe($o,$key,$def){if($o -eq $null){return [double]$def};$v=QProp $o $key;if(IsBlank $v){return [double]$def};try{return [double]$v}catch{return [double]$def}}
function ApplyQdtCalibration($g,$c,$d){
  $obj=QProp $d 'calibration';if($obj -eq $null){$obj=QProp $c 'calibration'};
  $dx=QCalNumSafe $obj 'offset_x_mm' 0;$dy=QCalNumSafe $obj 'offset_y_mm' 0;$sx=QCalNumSafe $obj 'scale_x_pct' 100;$sy=QCalNumSafe $obj 'scale_y_pct' 100;
  if($sx -le 0){$sx=100};if($sy -le 0){$sy=100};$kx=$sx/100;$ky=$sy/100;$tx=QMM($dx);$ty=QMM($dy);
  try{$g.TranslateTransform([single]$tx,[single]$ty)}catch{}
  try{$g.ScaleTransform([single]$kx,[single]$ky)}catch{}
  return $true
}
function DrawConfiguredJob($g,$d,$font,$small,$bold,$pen){
  $cfg=QProp $d 'print_config'; if($cfg -eq $null){return $false}
  $positions=QProp $cfg 'positions'; $hidden=QProp $cfg 'hidden'; $custom=QProp $cfg 'customBlocks'
  $footer=QProp $cfg 'footer'; $fields=QProp $cfg 'fields'; $paper=QProp $cfg 'paper'; $rows=QProp $cfg 'rows'; $colsCfg=QProp $cfg 'columns'
  $L=QProp $d 'labels'; $C=QProp $cfg 'company'; $footerData=QProp $cfg 'footer'; $footer=$footerData; $items=QProp $d 'items'; if($items -eq $null){$items=@()}else{$items=@($items)}
  $pageWmm=240;$mr=6;$ml=6;$mt=5;$tg=2;$hg=2;$fg=2;$toff=0
  if($paper -ne $null){$v=QProp $paper 'width_mm';if($v){$pageWmm=[double]$v};$v=QProp $paper 'margin_right_mm';if($v){$mr=[double]$v};$v=QProp $paper 'margin_left_mm';if($v){$ml=[double]$v};$v=QProp $paper 'margin_top_mm';if($v){$mt=[double]$v};$v=QProp $paper 'title_gap_mm';if($v){$tg=[double]$v};$v=QProp $paper 'head_gap_mm';if($v){$hg=[double]$v};$v=QProp $paper 'foot_gap_mm';if($v){$fg=[double]$v};$v=QProp $paper 'title_offset_x_mm';if($v){$toff=[double]$v}}
  $tp=QProp $positions 'table'; if($tp -eq $null){$tp=@{x=6;y=28}}
  $tx=QMM($ml+[double](QProp $tp 'x'));$ty=QMM($mt+$hg+[double](QProp $tp 'y'))
  $twmm=$pageWmm-[double](QProp $tp 'x')-$ml-$mr;if($twmm -lt 40){$twmm=40};$tw=QMM($twmm)
  $buyer=Cn(QProp $d 'buyer');$pay=Cn(QProp $d 'pay_method')
  $book=[string]::Join('',@([char]0x8BB0,[char]0x8D26));$credit=[string]::Join('',@([char]0x8D26,[char]0x671F));if($pay -eq $book){$pay=$credit}
  $bl=Cn(QProp $fields 'buyer');if([string]::IsNullOrEmpty($bl)){$bl=Cn(QProp $L 'buyer')}
  $sd=Cn(QProp $fields 'saleDate');if([string]::IsNullOrEmpty($sd)){$sd=Cn(QProp $L 'saleDate')}
  $bn=Cn(QProp $fields 'billNo');if([string]::IsNullOrEmpty($bn)){$bn=Cn(QProp $L 'billNo')}
  $ca=Cn(QProp $fields 'customerAddress');if([string]::IsNullOrEmpty($ca)){$ca=Cn(QProp $L 'customerAddress')}
  $cp=Cn(QProp $fields 'customerPhone');if([string]::IsNullOrEmpty($cp)){$cp=Cn(QProp $L 'customerPhone')}
  $op=Cn(QProp $fields 'operator');if([string]::IsNullOrEmpty($op)){$op=Cn(QProp $L 'operator')}
  $cl=Cn(QProp $footer 'customer_label');if([string]::IsNullOrEmpty($cl)){$cl=Cn(QProp $L 'customer')}
  $bk=Cn(QProp $footer 'bank_label');if([string]::IsNullOrEmpty($bk)){$bk=Cn(QProp $L 'bank')}
  $pd=Cn(QProp $footer 'paid_label');if([string]::IsNullOrEmpty($pd)){$pd=Cn(QProp $L 'paid')}
  $sg=Cn(QProp $footer 'signature_label');if([string]::IsNullOrEmpty($sg)){$sg=Cn(QProp $L 'signature')}
  $pm=Cn(QProp $footer 'pay_method_label');if([string]::IsNullOrEmpty($pm)){$pm=Cn(QProp $L 'pay_method')}
  $companyLine=[string]::Join(' ',@((Cn(QProp $C 'name')),(Cn(QProp $C 'address')),(Cn(QProp $C 'phone')),(Cn(QProp $C 'footer')))).Trim()
  $texts=@{}
  $texts['title']=Cn(QProp $L 'title');if((Cn(QProp $d 'doc_type')) -eq 'return'){$texts['title']=Cn(QProp $d 'return_title')}
  $texts['buyer']=$bl+': '+$buyer
  $texts['dateNo']=$sd+': '+(Cn(QProp $d 'sale_date'))+'   '+$bn+': '+(Cn(QProp $d 'bill_no'))
  $texts['address']=$ca+': '+(Cn(QProp $d 'customer_address'))
  $texts['phone']=$cp+': '+(Cn(QProp $d 'customer_phone'))
  $texts['operator']=$op+': '+(Cn(QProp $d 'operator'))
  $texts['bottomCustomer']=$cl+': '+$buyer
  $texts['bottomCompany']=$companyLine
  $texts['bottomBank']=$bk+': '+(Cn(QProp $footer 'bank_account'))
  $texts['bottomPaid']=$pd+': '+(Cn(QProp $d 'paid_amount'))
  $texts['bottomPay']=$pm+': '+$pay
  $texts['bottomSignature']=$sg+': '+(Cn(QProp $footer 'signature_value'))
  $texts['bottomNote']=Cn(QProp $footer 'note')
  $keys=@('title','buyer','dateNo','address','phone','operator','bottomCustomer','bottomCompany','bottomBank','bottomPaid','bottomPay','bottomSignature','bottomNote')
  foreach($k in $keys){
    if(QBool(QProp $hidden $k)){continue}
    if($k -eq 'bottomCustomer' -and (QProp $footer 'show_customer') -eq $false){continue}
    if($k -eq 'bottomCompany' -and (QProp $footer 'show_company') -eq $false){continue}
    if($k -eq 'bottomBank' -and (QProp $footer 'show_bank') -eq $false){continue}
    if($k -eq 'bottomPaid' -and (QProp $footer 'show_paid') -eq $false){continue}
    if($k -eq 'bottomPay' -and (QProp $footer 'show_pay_method') -eq $false){continue}
    if($k -eq 'bottomSignature' -and (QProp $footer 'show_signature') -eq $false){continue}
    $p=QProp $positions $k;if($p -eq $null){continue}
    $x=QMM($ml+[double](QProp $p 'x'));$titleOffset=QMM($toff);$dy=$mt+$tg;if($k -eq 'title'){$dy=$mt;$x=$x+$titleOffset}elseif($k.StartsWith('bottom')){$dy=$mt+$fg}
    $y=QMM($dy+[double](QProp $p 'y'));$txt=[string]($texts[$k]);if([string]::IsNullOrEmpty($txt)){continue}
    if($k -eq 'title'){$sf=New-Object System.Drawing.StringFormat;$ta=Cn(QProp $paper 'title_align');if($ta -eq 'left'){$sf.Alignment=[System.Drawing.StringAlignment]::Near}elseif($ta -eq 'right'){$sf.Alignment=[System.Drawing.StringAlignment]::Far}else{$sf.Alignment=[System.Drawing.StringAlignment]::Center};$rect=New-Object System.Drawing.RectangleF([single]$x,[single]$y,[single]$tw,[single]36);$g.DrawString($txt,$bold,[Drawing.Brushes]::Black,$rect,$sf)}else{QD $g $small $txt $x $y}
  }
  if($custom -ne $null){foreach($b in @($custom)){$k=Cn(QProp $b 'key');if(QBool(QProp $hidden $k)){continue};$p=QProp $positions $k;if($p -eq $null){continue};$x=QMM($ml+[double](QProp $p 'x'));$y=QMM($mt+$tg+[double](QProp $p 'y'));QD $g $small (Cn(QProp $b 'text')) $x $y}}
  $vcols=@();if($colsCfg -ne $null){foreach($c in @($colsCfg)){if((QProp $c 'show') -ne $false){$vcols+=$c}}}
  if($vcols.Count -eq 0){return $true}
  $widths=@();$sum=0;foreach($c in $vcols){$pct=0;try{$pct=[double](([string](QProp $c 'width')).Replace('%',''))}catch{$pct=0};if($pct -le 0){$pct=10};$widths+=$pct;$sum+=$pct};if($sum -le 0){$sum=100}
  $colX=@();$cur=$tx;foreach($w in $widths){$colX+=$cur;$cur+=$tw*$w/$sum};$colX+=$tx+$tw
  $hh=QMM([double](QProp $rows 'header_height'));if($hh -le 0){$hh=QMM(8)}
  $rh=QMM([double](QProp $rows 'item_height'));if($rh -le 0){$rh=QMM(8)}
  $fh=QMM([double](QProp $rows 'footer_height'));if($fh -le 0){$fh=QMM(9)}
  $n=0;try{$n=[int](QProp $rows 'item_rows')}catch{$n=0};if($n -lt 1){$n=8};if($n -gt 30){$n=30};if($items.Count -gt $n){$n=$items.Count}
  $y=$ty;for($k=0;$k -lt $vcols.Count;$k++){$g.DrawRectangle($pen,[single]$colX[$k],[single]$y,[single]($colX[$k+1]-$colX[$k]),[single]$hh);QD $g $small (Cn(QProp $vcols[$k] 'label')) ($colX[$k]+2) ($y+2)};$y+=$hh
  for($i=0;$i -lt $n;$i++){$it=$null;if($i -lt $items.Count){$it=$items[$i]};for($k=0;$k -lt $vcols.Count;$k++){$key=Cn(QProp $vcols[$k] 'key');$val=QProp $it $key;if($key -eq 'index' -and [string]::IsNullOrEmpty([string](Cn $val))){$val=$i+1};if($key -eq 'pay_method'){$val=$pay};$g.DrawRectangle($pen,[single]$colX[$k],[single]$y,[single]($colX[$k+1]-$colX[$k]),[single]$rh);QD $g $small (Cn $val) ($colX[$k]+2) ($y+2)};$y+=$rh}
  $tot=@{index=Cn(QProp $L 'total');name=(Cn(QProp $d 'sale_time'))+' '+(Cn(QProp $d 'sale_date'));qty=Cn(QProp $d 'total_qty');amount=Cn(QProp $d 'total_amount');pay_method=$pay}
  for($k=0;$k -lt $vcols.Count;$k++){$key=Cn(QProp $vcols[$k] 'key');$val='';if($tot.ContainsKey($key)){$val=$tot[$key]};$g.DrawRectangle($pen,[single]$colX[$k],[single]$y,[single]($colX[$k+1]-$colX[$k]),[single]$fh);QD $g $small $val ($colX[$k]+2) ($y+2)}
  return $true
}

function PrintJobObject($c,$obj,$printerName){
  [void][Reflection.Assembly]::LoadWithPartialName('System.Drawing')
  $pd=New-Object System.Drawing.Printing.PrintDocument
  if($printerName){$pd.PrinterSettings.PrinterName=$printerName}
  if(-not $pd.PrinterSettings.IsValid){throw 'Printer not available: '+$printerName}
  $pjPaper=QProp $obj 'paper';if($pjPaper -ne $null){$w=QProp $pjPaper 'width_mm';$h=QProp $pjPaper 'height_mm';if($w){$c.paper_width_mm=[double]$w};if($h){$c.paper_height_mm=[double]$h}}
  SetPaper $pd $c
  $font=New-Object System.Drawing.Font('Microsoft YaHei',9)
  $small=New-Object System.Drawing.Font('Microsoft YaHei',8)
  $bold=New-Object System.Drawing.Font('Microsoft YaHei',15,[Drawing.FontStyle]::Bold)
  $pen=[Drawing.Pens]::Black
  $script:obj=$obj
  $handler=[System.Drawing.Printing.PrintPageEventHandler]{
    param($sender,$e)
    $g=$e.Graphics;$d=$script:obj;ApplyQdtCalibration $g $c $d | Out-Null;if(DrawConfiguredJob $g $d $font $small $bold $pen){$e.HasMorePages=$false;return}$L=$d.labels;$C=$d.company;$items=@($d.items)
    $W=945;$H=375;$left=20;$right=$W-20;$top=8
    $title=(Cn $L.title);if($d.return_title -and [string]$d.doc_type -eq 'return'){$title=(Cn $d.return_title)};if($d.doc_type -eq 'return' -and $d.labels -and $d.labels.title -and -not $d.return_title){$oldTitle=[string]::Join('',@([char]0x9001,[char]0x8D27,[char]0x5355));$newTitle=[string]::Join('',@([char]0x9000,[char]0x8D27,[char]0x5355));$title=([string]$d.labels.title).Replace($oldTitle,$newTitle)};$sf=New-Object System.Drawing.StringFormat;$sf.Alignment=[System.Drawing.StringAlignment]::Center;$ta=if($d.title_align){[string]$d.title_align}else{'center'};if($ta -eq 'left'){$sf.Alignment=[System.Drawing.StringAlignment]::Near}elseif($ta -eq 'right'){$sf.Alignment=[System.Drawing.StringAlignment]::Far};$toff=0;if($d.title_offset_x_mm){$toff=[single]$d.title_offset_x_mm/25.4*100};$rect=New-Object System.Drawing.RectangleF([single]($left+$toff),[single]12,[single]($right-$left),[single]36);$g.DrawString($title,$bold,[Drawing.Brushes]::Black,$rect,$sf)
    DrawText $g $font ((Cn $L.buyer)+': '+(Cn $d.buyer)) 25 42
    DrawText $g $font ((Cn $L.saleDate)+': '+(Cn $d.sale_date)+'   '+(Cn $L.billNo)+': '+(Cn $d.bill_no)) 470 42
    DrawText $g $font ((Cn $L.customerAddress)+': '+(Cn $d.customer_address)) 25 62
    DrawText $g $font ((Cn $L.customerPhone)+': '+(Cn $d.customer_phone)) 470 62
    DrawText $g $font ((Cn $L.operator)+': '+(Cn $d.operator)) 470 82
    $ty=92;$rh=25;$cols=@(0,50,455,510,565,635,720,835,$right)
    for($k=0;$k -lt $cols.Count-1;$k++){$g.DrawRectangle($pen,[single]$cols[$k],[single]$ty,[single]($cols[$k+1]-$cols[$k]),[single]$rh)}
    $heads=@($L.columns)
    for($k=0;$k -lt $heads.Count;$k++){DrawText $g $small (Cn $heads[$k]) ($cols[$k]+4) ($ty+5)}
    $y=$ty+$rh
    for($i=0;$i -lt 9;$i++){
      $x=$items[$i];if($null -eq $x){$x=@{}}
      for($k=0;$k -lt $cols.Count-1;$k++){$g.DrawRectangle($pen,[single]$cols[$k],[single]$y,[single]($cols[$k+1]-$cols[$k]),[single]$rh)}
      DrawText $g $small (Cn $x.index) ($cols[0]+4) ($y+5)
      DrawText $g $small (Cn $x.name) ($cols[1]+4) ($y+5)
      DrawText $g $small (Cn $x.unit) ($cols[2]+4) ($y+5)
      DrawText $g $small (Cn $x.qty) ($cols[3]+4) ($y+5)
      DrawText $g $small (Cn $x.unit_price) ($cols[4]+4) ($y+5)
      DrawText $g $small (Cn $x.amount) ($cols[5]+4) ($y+5)
      DrawText $g $small (Cn $x.note) ($cols[6]+4) ($y+5)
      $y+=$rh
    }
    for($k=0;$k -lt $cols.Count-1;$k++){$g.DrawRectangle($pen,[single]$cols[$k],[single]$y,[single]($cols[$k+1]-$cols[$k]),[single]$rh)}
    DrawText $g $small (Cn $L.total) ($cols[0]+4) ($y+5)
    DrawText $g $small ((Cn $d.sale_time)+' '+(Cn $d.sale_date)) ($cols[1]+4) ($y+5)
    DrawText $g $small (Cn $d.total_qty) ($cols[3]+4) ($y+5)
    DrawText $g $small (Cn $d.total_amount) ($cols[5]+4) ($y+5)
    $fy=$y+$rh+6
    DrawText $g $small ((Cn $L.bank)+': '+(Cn $d.bank_account)) 25 $fy
    DrawText $g $small ((Cn $L.paid)+': '+(Cn $d.paid_amount)) 360 $fy
    DrawText $g $small ((Cn $L.signature)+':') 650 $fy
    DrawText $g $small ((Cn $C.address)+'  '+(Cn $C.phone)+'  '+(Cn $C.footer)) 25 ($fy+20)
    $e.HasMorePages=$false
  }
  $pd.add_PrintPage($handler)
  $pd.Print()
}
function PrintText($c,$text,$printerName){
  [void][Reflection.Assembly]::LoadWithPartialName('System.Drawing')
  $pd=New-Object System.Drawing.Printing.PrintDocument
  if($printerName){$pd.PrinterSettings.PrinterName=$printerName}
  SetPaper $pd $c
  $font=New-Object System.Drawing.Font('Microsoft YaHei',10)
  $script:lines=([string]$text) -split '\r?\n'
  $handler=[System.Drawing.Printing.PrintPageEventHandler]{param($sender,$e);$g=$e.Graphics;$y=20.0;foreach($line in $script:lines){$g.DrawString([string]$line,$font,[Drawing.Brushes]::Black,20.0,[single]$y);$y+=18};$e.HasMorePages=$false}
  $pd.add_PrintPage($handler)
  $pd.Print()
}
if($AutoConfigure){
  $c=LoadConfig
  if([string]::IsNullOrWhiteSpace($c.token)){$c.token=$DefaultToken}
  if([string]::IsNullOrWhiteSpace($c.url)){$c.url=$DefaultUrl}
  SaveConfig $c
  $label='Windows default';if(-not[string]::IsNullOrWhiteSpace($c.printer)){$label=$c.printer}
  Write-Host 'Auto configuration ready. No input required.'
  Write-Host ('URL='+$c.url+' Printer='+$label+' Paper='+$c.paper_width_mm+'x'+$c.paper_height_mm+'mm')
  exit 0
}
if($Configure){
  $c=LoadConfig;$u=Read-Host ('URL (Enter='+$DefaultUrl+')');if(-not[string]::IsNullOrWhiteSpace($u)){$c.url=$u.Trim().TrimEnd('/')}
  $t=Read-Host 'Agent token (Enter=keep preset)';if(-not[string]::IsNullOrWhiteSpace($t)){$c.token=$t.Trim()}
  ShowPrinters;$p=Read-Host 'Printer number/name (Enter=default,*=list)';if($p -eq '*'){ShowPrinters;$p=Read-Host 'Printer number/name'}
  if([string]::IsNullOrWhiteSpace($p)){$c.printer=''}elseif(($p -match '^[0-9]+$') -and ([int]$p -gt 0)){$a=Printers;$i=[int]$p;if($i -le $a.Count){$c.printer=[string]$a[$i-1]}else{$c.printer=$p}}else{$c.printer=$p}
  SaveConfig $c;Write-Host ('Saved URL='+$c.url+' Printer='+$c.printer);exit 0
}
$c=LoadConfig;if([string]::IsNullOrWhiteSpace($c.token)){throw 'Missing token'}
if($TestPrinter){
  $label='Windows default';if($c.printer){$label=$c.printer}
  Write-Host ('Testing printer: '+$label)
  PrintText $c ([IO.File]::ReadAllText((Join-Path $Dir 'test-print.txt'),[Text.Encoding]::UTF8)) $c.printer
  $h=Api $c $Health 'GET' $null;Write-Host ('Server '+$h.version+' / '+$h.security_level)
  $j=Api $c $Pending 'GET' $null;Write-Host ('Token OK. Pending='+@($j.rows).Count)
  Write-Host 'Test finished';exit 0
}
Write-Host '=== QudingTong Print Agent v1.3.2 started ==='
$label='Windows default';if($c.printer){$label=$c.printer}
Write-Host ('URL='+$c.url+' Printer='+$label+' Paper='+$c.paper_width_mm+'x'+$c.paper_height_mm+'mm Poll=3s')
while($true){
 try{
  $j=Api $c $Pending 'GET' $null
  foreach($job in @($j.rows)){
   $id=[string]$job.id;if($Seen.ContainsKey($id)){continue};$Seen[$id]=$true
   $claim=Api $c ('/api/admin/print/jobs/'+$id+'/claim') 'POST' @{token=([guid]::NewGuid().ToString('N'))}
   if(-not $claim.ok -or -not $claim.claimed){continue}
   try{
    $raw=[string]$job.payload;$obj=$null;try{$obj=$raw|ConvertFrom-Json}catch{}
    if($obj -and $obj.type -eq 'delivery_note'){PrintJobObject $c $obj $c.printer}else{PrintText $c $raw $c.printer}
    [void](Api $c ('/api/admin/print/jobs/'+$id+'/status') 'POST' @{status=$Done;error='';token=$claim.token})
    Write-Host ('['+(Get-Date -Format 'HH:mm:ss')+'] Printed '+$job.order_no)
   }catch{
    $err=[string]$_.Exception.Message;Write-Host ('Print failed '+$job.order_no+': '+$err)
    try{[void](Api $c ('/api/admin/print/jobs/'+$id+'/status') 'POST' @{status=$Failed;error=$err;token=$claim.token})}catch{}
   }
  }
 }catch{Write-Host ('['+(Get-Date -Format 'HH:mm:ss')+'] Poll failed: '+$_.Exception.Message)}
 Start-Sleep -Milliseconds 3000
}